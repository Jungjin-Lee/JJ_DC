﻿public class SocketConnect : JJSocket {
}
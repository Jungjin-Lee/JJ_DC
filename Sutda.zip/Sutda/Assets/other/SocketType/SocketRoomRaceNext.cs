﻿public class SocketRoomRaceNext : JJSocket {
	public int n;

	public SocketRoomRaceNext() {
		type = JJSocketType.RoomRaceNext;
	}
}
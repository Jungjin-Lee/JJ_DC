﻿public class SocketRoomPlay : JJSocket {

	public SocketRoomPlay() {
		type = JJSocketType.RoomPlay;
	}
}
﻿public class SocketRoomGiveCard : JJSocket {
	public int n = 0;
	public string c = "";

	public SocketRoomGiveCard() {
		type = JJSocketType.RoomGiveCard;
	}
}
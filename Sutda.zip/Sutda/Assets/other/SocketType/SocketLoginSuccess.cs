﻿public class SocketLoginSuccess : JJSocket {
	public string name;

	public SocketLoginSuccess() {
		type = JJSocketType.LoginSuccess;
	}
}